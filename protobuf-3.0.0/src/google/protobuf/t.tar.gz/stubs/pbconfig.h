// Note: Google Protobuf internal only. Do NOT include.
 #define GOOGLE_PROTOBUF_HASH_MAP_CLASS unordered_map
 #define GOOGLE_PROTOBUF_HASH_MAP_H <tr1/unordered_map>
 #define GOOGLE_PROTOBUF_HASH_NAMESPACE std::tr1
 #define GOOGLE_PROTOBUF_HASH_SET_CLASS unordered_set
 #define GOOGLE_PROTOBUF_HASH_SET_H <tr1/unordered_set>
 #define GOOGLE_PROTOBUF_HAVE_HASH_MAP 1
 #define GOOGLE_PROTOBUF_HAVE_HASH_SET 1
